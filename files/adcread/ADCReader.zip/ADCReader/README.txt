$Id: README.txt, v 1.4 2013/11/15 16:11:43  $

README for ADCReader


Author/Contact:

  behdad@kth.se

Description:

ADCReader

The ADCReader application is a sample application to show how to read ADC data. This application will read the data from ADC0 and ADC1. Whenever a DAC data is received, the three least significant bits in the ADC0 value are displayed on the LEDs.

