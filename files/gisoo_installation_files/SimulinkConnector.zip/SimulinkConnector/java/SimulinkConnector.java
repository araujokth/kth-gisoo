/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author behdad
 */
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JCheckBox;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;

import org.apache.log4j.Logger;
import org.jdom.Element;

import se.sics.cooja.ClassDescription;
import se.sics.cooja.GUI;
import se.sics.cooja.Mote;
import se.sics.cooja.MotePlugin;
import se.sics.cooja.PluginType;
import se.sics.cooja.Simulation;
import se.sics.cooja.VisPlugin;
import se.sics.cooja.interfaces.SerialPort;
import se.sics.cooja.TimeEvent;

import java.util.Collection;
import java.util.Observable;
import java.util.Observer;

import se.sics.cooja.mspmote.SkyMote;
import se.sics.mspsim.core.ADC12;
import se.sics.mspsim.core.ADCInput;
import se.sics.mspsim.core.IOUnit;
import se.sics.mspsim.core.DAC12;
import se.sics.mspsim.core.DACOutput;

//UDP Sending
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

//For Writing in a text file
import java.io.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;


/////////////

//SerialSocketServer
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collection;
import java.util.Observable;
import java.util.Observer;
import java.util.logging.Level;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.plaf.basic.BasicMenuUI;

import org.apache.log4j.Logger;
import org.jdom.Element;

import se.sics.cooja.ClassDescription;
import se.sics.cooja.GUI;
import se.sics.cooja.Mote;
import se.sics.cooja.MotePlugin;
import se.sics.cooja.PluginType;
import se.sics.cooja.Simulation;
import se.sics.cooja.VisPlugin;
import se.sics.cooja.interfaces.SerialPort;
/////////

@ClassDescription("SimulinkConnector")
@PluginType(PluginType.MOTE_PLUGIN)
public class SimulinkConnector extends VisPlugin implements MotePlugin {

    private static Logger logger = Logger.getLogger(SimulinkConnector.class);
    private Simulation sim;
    private Mote mote;
    private SkyMote skyMote;
    public final int LISTEN_PORT;
    public final int LISTEN_PORT_FOR_TCP;
    private ServerSocket server;
    private Socket client;
    private DatagramSocket dSocket;
    private DatagramPacket dPacket;
    private int simulationTime;
    private byte[] buffer = new byte[4];
    private byte[] toRCV = new byte[4];
    private byte[] toRCVSerial = new byte[24];
    private JCheckBox serialDataShouldRCV;
    private JTextField CPUDellay;  //Simulinkport, IPTextfield,
    private final static int LABEL_WIDTH = 180;
    private final static int LABEL_HEIGHT = 35;
    private JLabel statusLabel;//, simulinkPort, outLabel;
    private File adcFile = new File("C:/ADCDACTime/ADCTime.txt");
    private File dacFile = new File("C:/ADCDACTime/DACTime.txt");
    private File serialFileSend = new File("C:/ADCDACTime/SerialTimeSend.txt");/////////////
    private File serialFileRCV = new File("C:/ADCDACTime/SerialTimeRCV.txt");
    private boolean DACWrittenForFirst = true;
    private boolean ADCWrittenForFirst = true;
    private boolean SerialRCVWrittenForFirst = true;
    private boolean SerialSendWrittenForFirst = true;
    private long lastTimeForFile = 0;
    private int serialPinNumber;
    private int serialPinNumber2;
    private SerialPort serialPort;
    private Observer serialDataObserver;
    int nRCVedByte = 0;
    int sizeOfPayload = 0;
    int messageIndex = 0;
    byte lastByte;
    byte[] msgHeader = new byte[5];
    byte[] message = new byte[28];
    final byte[] serialPayload = new byte[16];
    boolean serialSendFlag;
    private DataInputStream in;
    // private JCheckBox serialReplyDelay;

    protected class ADCConnector implements ADCInput {

        private int pinNumber;
        private int motePinId;
//        private int pinId;
//        boolean correctMsgRcved;

        public ADCConnector(int pin) {

            pinNumber = pin;
        }

        @Override
        public int nextData() {

            //Simulation Time
            simulationTime = (int) sim.getSimulationTimeMillis();
            logger.info("Simulation time is: " + simulationTime);

            //MotePinId
            motePinId = (skyMote.getID() * 100) + pinNumber;
            logger.info("motePinId is: " + motePinId);

            byte[] message = adcRequestMsgCreator(simulationTime, motePinId);
            int sensorValue = adcRequestSender(message, dSocket);
            logger.info("Sensor Value is: " + sensorValue);
            fileWriter(motePinId, sensorValue);
            return (sensorValue);


        }
        
    protected int adcRequestSender(byte[] message, DatagramSocket dgSocket) {

        try {
            InetAddress IPAddress = InetAddress.getByName("localhost");
            DatagramPacket dgPacket = new DatagramPacket(message, message.length, IPAddress, 55555);
            dgSocket.send(dgPacket);
        } catch (IOException ex) {
            System.out.println("Error in sending dgPacket in adcRequestSender!!");
        }
        byte[] receivedValue = new byte[4];
        DatagramPacket receivedPacket = new DatagramPacket(receivedValue, receivedValue.length);
        try {
            dgSocket.receive(receivedPacket);
        } catch (IOException ex) {
            System.out.println("Error in receive UDP data adcRequestSender!!");
            System.out.println(ex.getMessage());
        }
     //   byte[] data = reverseArray(receivedPacket.getData());
        byte[] data = receivedPacket.getData();
        return (bytes2Int1(data));
    }
    
    int bytes2Int1(byte[] bytes) {
        return ((int) (0xff & bytes[0]) << 24
                | (int) (0xff & bytes[1]) << 16
                | (int) (0xff & bytes[2]) << 8
                | (int) (0xff & bytes[3]) << 0);
    }
        
      protected  byte[] adcRequestMsgCreator(int simulationTime, int motePinId) {
        int uValue = 0;
        byte[] emptySerialData = new byte[16];
        for (byte b : emptySerialData) {
            b = 0;
        }

        byte[] simulationTimeInByte = int2Bytes(simulationTime);
        byte[] motePinIdInByte = int2Bytes(motePinId);
        byte[] uValueInByte = int2Bytes1(uValue);

        byte[] message = combine1(reverseArray(simulationTimeInByte), reverseArray(motePinIdInByte), reverseArray(uValueInByte), emptySerialData);

        return (message);
    }
      
   protected byte[] combine1(byte[] one, byte[] two) {
        byte[] combined = new byte[one.length + two.length];

        System.arraycopy(one, 0, combined, 0, one.length);
        System.arraycopy(two, 0, combined, one.length, two.length);
        return combined;
    }

   protected byte[] combine1(byte[] one, byte[] two, byte[] three) {
        byte[] combined = new byte[one.length + two.length + three.length];

        System.arraycopy(one, 0, combined, 0, one.length);
        System.arraycopy(two, 0, combined, one.length, two.length);
        System.arraycopy(three, 0, combined, one.length + two.length, three.length);
        return combined;
    }

 protected byte[] combine1(byte[] one, byte[] two, byte[] three, byte[] four) {
        byte[] combined = new byte[one.length + two.length + three.length + four.length];

        System.arraycopy(one, 0, combined, 0, one.length);
        System.arraycopy(two, 0, combined, one.length, two.length);
        System.arraycopy(three, 0, combined, one.length + two.length, three.length);
        System.arraycopy(four, 0, combined, one.length + two.length + three.length, four.length);
        return combined;
    }
    
    protected   byte[] int2Bytes1(int inputInt) {

        byte[] resultByts = new byte[]{
            (byte) ((inputInt >> 24) & 0xff),
            (byte) ((inputInt >> 16) & 0xff),
            (byte) ((inputInt >> 8) & 0xff),
            (byte) ((inputInt >> 0) & 0xff),};
        return resultByts;
    }
     
    }

    protected class DACConnector implements DACOutput {

        private int pinNumber;
        private int motePinId;

        public DACConnector(int pin) {

            pinNumber = pin;
            logger.info("14");
        }

        public void setDACPin0(int value) {
            simulationTime = (int) sim.getSimulationTimeMillis();
            motePinId = (skyMote.getID() * 100) + 16;// pinNumber;

            byte[] message = dacMessageCreator(simulationTime, motePinId, value);


            if (skyMote.skyNode.radio.isReadyToReceive()) {//&& u != 0) {
                int confirmedAppliedUValue  = dacValueSender(message, dSocket);
                fileWriter(motePinId, confirmedAppliedUValue);
                logger.info("DAC Value:" + confirmedAppliedUValue );
            }
            //   logger.info("End of if");

        }

        public void setDACPin1(int value) {
            simulationTime = (int) sim.getSimulationTimeMillis();
            motePinId = (skyMote.getID() * 100) + 17;//pinNumber;

            byte[] message = dacMessageCreator(simulationTime, motePinId, value);

            int u = value;


            if (skyMote.skyNode.radio.isReadyToReceive() && u != 0) {
                int confirmedAppliedUValue = dacValueSender(message, dSocket);
                fileWriter(motePinId, confirmedAppliedUValue);
                logger.info("DAC Value:" + confirmedAppliedUValue );


            }
        }
        
        byte[] dacMessageCreator(int simulationTime, int motePinId, int uValue) {

        byte[] emptySerialData = new byte[16];
        for (byte b : emptySerialData) {
            b = 0;
        }

        byte[] simulationTimeInByte = dacInt2Bytes(simulationTime);
        byte[] motePinIdInByte = dacInt2Bytes(motePinId);
        byte[] uValueInByte = dacInt2Bytes(uValue);

        byte[] message = dacCombine(reverseArray(simulationTimeInByte), reverseArray(motePinIdInByte), reverseArray(uValueInByte), emptySerialData);

        return (message);
    }
        
        int dacValueSender(byte[] message, DatagramSocket dgSocket) {

        try {
            InetAddress IPAddress = InetAddress.getByName("localhost");
            DatagramPacket dgPacket = new DatagramPacket(message, message.length, IPAddress, 55555);
            dgSocket.send(dgPacket);
        } catch (IOException ex) {
            System.out.println("Error in sending dgPacket in adcRequestSender!!");
        }
        byte[] receivedValue = new byte[4];
        DatagramPacket receivedPacket = new DatagramPacket(receivedValue, receivedValue.length);
        try {
            dgSocket.receive(receivedPacket);
        } catch (IOException ex) {
            System.out.println("Error in receive UDP data adcRequestSender!!");
            System.out.println(ex.getMessage());
        }
     //   byte[] data = reverseArray(receivedPacket.getData());
        byte[] data = receivedPacket.getData();
        return (dacBytes2Int(data));
    }
        
        byte[] dacCombine(byte[] one, byte[] two, byte[] three, byte[] four) {
        byte[] combined = new byte[one.length + two.length + three.length + four.length];

        System.arraycopy(one, 0, combined, 0, one.length);
        System.arraycopy(two, 0, combined, one.length, two.length);
        System.arraycopy(three, 0, combined, one.length + two.length, three.length);
        System.arraycopy(four, 0, combined, one.length + two.length + three.length, four.length);
        return combined;
    }
        
        byte[] dacInt2Bytes(int inputInt) {

        byte[] resultByts = new byte[]{
            (byte) ((inputInt >> 24) & 0xff),
            (byte) ((inputInt >> 16) & 0xff),
            (byte) ((inputInt >> 8) & 0xff),
            (byte) ((inputInt >> 0) & 0xff),};
        return resultByts;
    }
        
        int dacBytes2Int(byte[] bytes) {
        return ((int) (0xff & bytes[0]) << 24
                | (int) (0xff & bytes[1]) << 16
                | (int) (0xff & bytes[2]) << 8
                | (int) (0xff & bytes[3]) << 0);
    }
        
    }

    public SimulinkConnector(Mote mote, Simulation simulation, final GUI gui) {

        super("SimulinkConnector (" + mote + ")", gui, false);
        this.mote = mote;
        skyMote = (SkyMote) mote;
        sim = skyMote.getSimulation();
        LISTEN_PORT = 18000 + mote.getID();
        LISTEN_PORT_FOR_TCP = 19000 + mote.getID();
        logger.info("Listen on TCP port: " + LISTEN_PORT_FOR_TCP);

        if (GUI.isVisualized()) {
            Box northBox = Box.createHorizontalBox();
            northBox.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
            statusLabel = configureLabel(northBox, "", "");
            // statusLabel = new JLabel("5555");

            Box mainBox = Box.createHorizontalBox();
            mainBox.setBorder(BorderFactory.createEmptyBorder(0, 5, 5, 5));


            JPanel smallPane = new JPanel(new BorderLayout());
            JLabel simulinkPort = new JLabel("Simulink listen on port:");
            simulinkPort.setPreferredSize(new Dimension(LABEL_WIDTH, LABEL_HEIGHT));
            smallPane.add(BorderLayout.WEST, simulinkPort);
            JTextField SimulinkPortText = new JTextField("5555");
            SimulinkPortText.setPreferredSize(new Dimension(LABEL_WIDTH, LABEL_HEIGHT));
            smallPane.add(BorderLayout.CENTER, SimulinkPortText);
            mainBox.add(smallPane);


            Box southernBox = Box.createHorizontalBox();
            southernBox.setBorder(BorderFactory.createEmptyBorder(0, 5, 5, 5));


            JPanel smallPane2 = new JPanel(new BorderLayout());
            /*            
             serialDataShouldRCV= new JCheckBox("Serial data should be received");
             smallPane2.add(BorderLayout.CENTER,serialDataShouldRCV);
             southernBox.add(smallPane2);
             */


            serialDataShouldRCV = new JCheckBox("Serial reply should be received after(ms): ");
            //  serialReplyDelay=new JCheckBox("Seconding Serial Data");
            CPUDellay = new JTextField("1");
            CPUDellay.setPreferredSize(new Dimension(LABEL_WIDTH, LABEL_HEIGHT));

            smallPane2.add(BorderLayout.CENTER, serialDataShouldRCV);
            smallPane2.add(BorderLayout.EAST, CPUDellay);
            // smallPane2.add(BorderLayout.EAST, serialReplyDelay);
            southernBox.add(smallPane2);


            getContentPane().add(BorderLayout.NORTH, northBox);
            getContentPane().add(BorderLayout.CENTER, mainBox);
            getContentPane().add(BorderLayout.SOUTH, southernBox);
            pack();

        }

        /* Mote serial port */
        serialPort = (SerialPort) mote.getInterfaces().getLog();
        if (serialPort == null) {
            throw new RuntimeException("No mote serial port");
        }
        for (byte b : serialPayload) {
            b = 0;
        }

        logger.info("Listening on port: " + LISTEN_PORT);
        if (GUI.isVisualized()) {
            statusLabel.setText("Listening on port: " + LISTEN_PORT);
        }


        //#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%
        //#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%
        //#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%

//                            if (serialDataShouldRCV.isSelected()) //If the second has been selected (It should check the second scenario CheckBox )
//                    {
//                                logger.info("M1");
//
//                        logger.info("#1#1#1#1#1#1#1#1#1#1#1#1#1#1 Simulation Time is : " + sim.getSimulationTime());
//                        TimeEvent delayedEvent = new TimeEvent(0) {
//                            
//                            public void execute(long t) {
//                                logger.info("M3");
//                                logger.info("#2#2#2#2#2#2#2#2#2#2#2#2#2#2  Simulation Time is : " + sim.getSimulationTime());
//
//
//                                simulationTime = (int) sim.getSimulationTimeMillis();
//                                logger.info("When recoded Simulation Time is : " + sim.getSimulationTime());
//                                serialPinNumber = (skyMote.getID() * 100) + 19;//SerialDataRequest;
//                                logger.info("SerialPinNumber is : " + serialPinNumber);
//
//                                byte[] serialRequestMesg = serialRequestMsgCreator(simulationTime, serialPinNumber);
//                                logger.info("#0");
//                                serialDataRequestSender(serialRequestMesg, dSocket);
//                                logger.info("#1");
//
//
//                            }
//                        };
//                        logger.info("M2");
//                        sim.scheduleEvent(
//                                delayedEvent,
//                                sim.getSimulationTime() + (Long.parseLong(CPUDellay.getText())*(sim.MILLISECOND)));
//                        //sim.getSimulationTime() +(a)* sim.MILLISECOND);
//                    }
//        
        //#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%
        //#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%
        //#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%#%




        /* Observe serial port for outgoing data */
        serialPort.addSerialDataObserver(serialDataObserver = new Observer() {
            public void update(Observable obs, Object obj) {
                logger.info("test 1: Serial data has been received");
                serialSendFlag = false;
                /* Check the received message to find the moment that message follow the header format
                 "0x 00 ff ff 00 00" which is equal to "0 -1 -1 0 0" in decimal. The next byte after 
                 this message is the message size*/

                //////////
                //////////

                lastByte = serialPort.getLastSerialData();
                logger.info("lastByte: " + lastByte);
                if (lastByte == 126 && nRCVedByte < 7) {
                    nRCVedByte = 1;
                    //  messageIndex=0;
                } else if (nRCVedByte > 0 && nRCVedByte < 7) {
                    nRCVedByte++;
                } else if (nRCVedByte == 7) {
                    sizeOfPayload = lastByte;
                    logger.info("sizeOfPayload is: " + sizeOfPayload);
                    nRCVedByte++;
                } else if (nRCVedByte > 7 && nRCVedByte < 10) {
                    nRCVedByte++;
                } else if (nRCVedByte >= 10 && nRCVedByte < 10 + sizeOfPayload) {
                    logger.info("nRCVedByte: " + nRCVedByte);
                    logger.info("messageIndex: " + messageIndex);

                    serialPayload[messageIndex] = lastByte;
                    logger.info("messageIndex: " + messageIndex + "   lastByte: " + lastByte);
                    if (nRCVedByte == (10 + sizeOfPayload - 1)) {
                        messageIndex = 0;
                        serialSendFlag = true;
                    } else {
                        messageIndex++;
                    }
                    nRCVedByte++;
                } else {
                    nRCVedByte = 0;
                }

                //////////
                //////////

//                
//                
//                
//                
//                
//                if (nRCVedByte < 5) {
//                    logger.info("test 2:  nRCVedByte < 5");
//                    lastByte = serialPort.getLastSerialData();
//                    logger.info("lastByte: " + lastByte);
//                    if (lastByte == 0 && (nRCVedByte == 0 || nRCVedByte == 3 || nRCVedByte == 4)) {
//                        msgHeader[nRCVedByte] = lastByte;
//                        logger.info("test 3:   nRCVedByte: " + nRCVedByte + "   lastByte: " + lastByte);
//                        nRCVedByte++;
//                    } else if (lastByte == -1 && (nRCVedByte == 1 || nRCVedByte == 2)) {
//                        msgHeader[nRCVedByte] = lastByte;
//                        logger.info("test 4:   nRCVedByte: " + nRCVedByte + "   lastByte: " + lastByte);
//                        nRCVedByte++;
//
//                    } else {
//                        nRCVedByte = 0;
//                        logger.info("test 5:   nRCVedByte:  " + nRCVedByte + "   lastByte:  " + lastByte + "  it is improper byte");
//                    }
//                } else if (nRCVedByte == 5) {
//                    /*Receiving the size of Payload in message*/
//                    logger.info("test 6: nRCVedByte = 5 then Receiving the size of payload.");
//                    sizeOfPayload = serialPort.getLastSerialData();
//                    logger.info("sizeOfPayload is: " + sizeOfPayload);
//                    nRCVedByte++;
//                } else if (nRCVedByte < 8) {
//                    /*Passing to other bytes (handlerID and source address)*/
//                    logger.info("test 7: Passing the other data after SizeOfPayload and before payload.");
//                    lastByte = serialPort.getLastSerialData();
//                    nRCVedByte++;
//                } else if (nRCVedByte < (8 + sizeOfPayload)) {
//                    /*Receiving the message payload*/
//                    logger.info("test 8: Receiving the message payload.");
//                    serialPayload[messageIndex] = serialPort.getLastSerialData();
//                    logger.info("messageIndex: " + messageIndex + "  message: " + serialPayload[messageIndex]);
//                    messageIndex++;
//                    nRCVedByte++;
//                    if (nRCVedByte == (8 + sizeOfPayload)) {
//                        messageIndex = 0;
//                        nRCVedByte = 0;
//
//                        serialSendFlag = true;
//                    }
//                }
//                
//                
//                


                if (serialSendFlag) {

                    simulationTime = (int) sim.getSimulationTimeMillis();
                    serialPinNumber = (skyMote.getID() * 100) + 18;//pinNumber;
                    serialPinNumber2 = (skyMote.getID() * 100) + 19;//pinNumber;
                    int u = 0;//value;
                    logger.info("test  25");


                    byte[] serialDataMSG = serialMessageCreator(simulationTime, serialPinNumber, serialPayload);
                    fileWriter(serialPinNumber, serialPayload);
                    int q = serialMsgSender(serialDataMSG, dSocket);

                    serialSendFlag = false;

                    if (serialDataShouldRCV.isSelected()) //If the second has been selected (It should check the second scenario CheckBox )
                    {
                        logger.info("#1#1#1#1#1#1#1#1#1#1#1#1#1#1 Simulation Time is : " + sim.getSimulationTime());
                        TimeEvent delayedEvent = new TimeEvent(0) {
                            public void execute(long t) {
                                logger.info("#2#2#2#2#2#2#2#2#2#2#2#2#2#2  Simulation Time is : " + sim.getSimulationTime());


                                simulationTime = (int) sim.getSimulationTimeMillis();
                                logger.info("When recoded Simulation Time is : " + sim.getSimulationTime());
                                serialPinNumber = (skyMote.getID() * 100) + 19;//SerialDataRequest;
                                logger.info("SerialPinNumber is : " + serialPinNumber);

                                byte[] serialRequestMesg = serialRequestMsgCreator(simulationTime, serialPinNumber);
                                logger.info("#0");
                                serialRequestSender(serialRequestMesg, dSocket);
                                fileWriter(serialPinNumber, serialRequestMesg);
                                logger.info("#1");


                            }
                        };

                        sim.scheduleEvent(
                                delayedEvent,
                                sim.getSimulationTime() + (Long.parseLong(CPUDellay.getText()) * (sim.MILLISECOND)));
                        //sim.getSimulationTime() +(a)* sim.MILLISECOND);
                    }
                }

            }
        });



        try {
            dSocket = new DatagramSocket(LISTEN_PORT);//(18000 + skyMote.getID());
            if (GUI.isVisualized()) {
                statusLabel.setText("Mote listening on port: " + LISTEN_PORT);
            }

        } catch (SocketException ex) {
            System.out.println("Errore in dSocket creation");
        }

//        if (true) {    //if the second scenario has been selected
//            try {
//                server = new ServerSocket(LISTEN_PORT_FOR_TCP);
//                logger.info("Server Listen on POrt:  " + LISTEN_PORT_FOR_TCP);
//                
//                checkBoxChengeListener cBChListener = new checkBoxChengeListener();
//                serialDataShouldRCV.addChangeListener(cBChListener);
//                
//            } catch (IOException ex) {
//                java.util.logging.Logger.getLogger(SimulinkConnector.class.getName()).log(Level.SEVERE, null, ex);
//            }
//        }
        IOUnit adc = skyMote.getCPU().getIOUnit("ADC12");
        if (adc instanceof ADC12) {
            ((ADC12) adc).setADCInput(0, new ADCConnector(0));
            ((ADC12) adc).setADCInput(1, new ADCConnector(1));
            ((ADC12) adc).setADCInput(2, new ADCConnector(2));
            ((ADC12) adc).setADCInput(3, new ADCConnector(3));
            ((ADC12) adc).setADCInput(4, new ADCConnector(4));
            ((ADC12) adc).setADCInput(5, new ADCConnector(5));
            ((ADC12) adc).setADCInput(6, new ADCConnector(6));
            ((ADC12) adc).setADCInput(7, new ADCConnector(7));
            ((ADC12) adc).setADCInput(8, new ADCConnector(8));
            ((ADC12) adc).setADCInput(9, new ADCConnector(9));
            ((ADC12) adc).setADCInput(10, new ADCConnector(10));
            ((ADC12) adc).setADCInput(11, new ADCConnector(11));
            ((ADC12) adc).setADCInput(12, new ADCConnector(12));
            ((ADC12) adc).setADCInput(13, new ADCConnector(13));
            ((ADC12) adc).setADCInput(14, new ADCConnector(14));
            ((ADC12) adc).setADCInput(15, new ADCConnector(15));
        }

        ((DAC12) skyMote.getCPU().getIOUnit("DAC12")).setDACOutput(0, new DACConnector(16));
        ((DAC12) skyMote.getCPU().getIOUnit("DAC12")).setDACOutput(1, new DACConnector(17));


    }

    void fileWriter(int motePinId, int value) {

        //Writing the Simulation time and Sensor value in a file
        int pinId = 0;
        pinId = motePinId % 100;
        String content = "";
        
        if (pinId == 0){//|| pinId == 1|| pinId == 5){// || pinId == 1) {
            try {
//                String content = "";
                if (pinId == 0) {
                    content = (String.valueOf(motePinId) + '\t'+'\t' + String.valueOf( sim.getSimulationTimeMillis()) + '\t'+'\t'+ String.valueOf(value));
                }
                if (pinId == 1) {
                    content = (String.valueOf(motePinId) + '\t'+'\t'+ String.valueOf(sim.getSimulationTimeMillis()) + '\t'+'\t' + String.valueOf(value));
                }
                if (pinId == 5) {
                    content = (String.valueOf(motePinId) + '\t'+'\t'+ String.valueOf( sim.getSimulationTimeMillis()) + '\t'+'\t' + String.valueOf(value));
                }

                lastTimeForFile = sim.getSimulationTimeMillis();

                // if file doesn't exists, then create it
                if (!adcFile.exists()) {
                    adcFile.createNewFile();
                } else if (ADCWrittenForFirst) {
                    adcFile.delete();
                    adcFile.createNewFile();
                    ADCWrittenForFirst = false;
                }

                FileWriter fw = new FileWriter(adcFile.getAbsoluteFile(), true);

                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter pn = new PrintWriter(fw);
                pn.println(content);
                pn.close();

                logger.info("Done");
            } catch (Exception e) {//Catch exception if any
                logger.info("Error in print dacFile");
            }
        }else if(pinId==16||pinId==17){
         /////
                    try {

//                        String content2 = (String.valueOf(sim.getSimulationTimeMillis()) + "   " + String.valueOf(u));
                          content = (String.valueOf(motePinId) + '\t'+'\t'+ String.valueOf(sim.getSimulationTimeMillis()) + '\t'+'\t' + String.valueOf(value));

                        if (lastTimeForFile < sim.getSimulationTimeMillis()) {
                            lastTimeForFile = sim.getSimulationTimeMillis();

                            // if file doesnt exists, then create it
                            if (!dacFile.exists()) {
                                dacFile.createNewFile();
                            } else if (DACWrittenForFirst) {
                                dacFile.delete();
                                dacFile.createNewFile();
                                DACWrittenForFirst = false;
                            }

                            FileWriter fw = new FileWriter(dacFile.getAbsoluteFile(), true);

                            BufferedWriter bw = new BufferedWriter(fw);
                            PrintWriter pn = new PrintWriter(fw);
                            pn.println(content);
                            pn.close();
                        }
                        logger.info("Done");
                    } catch (Exception e) {//Catch exception if any
                        logger.info("Error in print dacFile");
                    }
                    /////
        }
        //End of writing


    }
    
    void fileWriter(int motePinId, byte[] message) {

        //Writing the Simulation time and Sensor value in a file
        int pinId = 0;
        pinId = motePinId % 100;
        String content = "";
        
        if (pinId == 18) {
            try {
//                String content = "";
              content = (String.valueOf(motePinId) + '\t'+'\t' + String.valueOf(sim.getSimulationTimeMillis()) + '\t'+'\t' + 
                      String.valueOf(message[0])+ '\t'+'\t' + String.valueOf(message[1])+ '\t'+'\t' +String.valueOf(message[2])+ '\t'+'\t' + String.valueOf(message[3])+ '\t'+'\t' + 
                      String.valueOf(message[4])+ '\t'+'\t' + String.valueOf(message[5])+ '\t'+'\t' + String.valueOf(message[6])+ '\t'+'\t' +String.valueOf(message[7])+ '\t'+'\t'+ 
                      String.valueOf(message[8])+ '\t'+'\t' + String.valueOf(message[9])+ '\t'+'\t' + String.valueOf(message[10])+ '\t'+'\t' + String.valueOf(message[11])+ '\t'+'\t'+
                      String.valueOf(message[12])+ '\t'+'\t' + String.valueOf(message[13])+ '\t'+'\t' + String.valueOf(message[14])+ '\t'+'\t'+ String.valueOf(message[15]));
                

                lastTimeForFile = sim.getSimulationTimeMillis();

                // if file doesn't exists, then create it
                if (!serialFileSend.exists()) {
                    serialFileSend.createNewFile();
                } else if (SerialSendWrittenForFirst) {
                    serialFileSend.delete();
                    serialFileSend.createNewFile();
                    SerialSendWrittenForFirst = false;
                }

                FileWriter fw = new FileWriter(serialFileSend.getAbsoluteFile(), true);

                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter pn = new PrintWriter(fw);
                pn.println(content);
                pn.close();

                logger.info("Done");
            } catch (Exception e) {//Catch exception if any
                logger.info("Error in print dacFile");
            }
        }else if(pinId==19){
          try {
//                String content = "";
            content = (String.valueOf(motePinId) + '\t'+'\t' + String.valueOf(sim.getSimulationTimeMillis()) + '\t'+'\t' + 
                      String.valueOf(message[0])+ '\t'+'\t' + String.valueOf(message[1])+ '\t'+'\t' +String.valueOf(message[2])+ '\t'+'\t' + String.valueOf(message[3])+ '\t'+'\t' + 
                      String.valueOf(message[4])+ '\t'+'\t' + String.valueOf(message[5])+ '\t'+'\t' + String.valueOf(message[6])+ '\t'+'\t' +String.valueOf(message[7])+ '\t'+'\t'+ 
                      String.valueOf(message[8])+ '\t'+'\t' + String.valueOf(message[9])+ '\t'+'\t' + String.valueOf(message[10])+ '\t'+'\t' + String.valueOf(message[11])+ '\t'+'\t'+
                      String.valueOf(message[12])+ '\t'+'\t' + String.valueOf(message[13])+ '\t'+'\t' + String.valueOf(message[14])+ '\t'+'\t'+ String.valueOf(message[15]));
                

                lastTimeForFile = sim.getSimulationTimeMillis();

                // if file doesn't exists, then create it
                if (!serialFileRCV.exists()) {
                    serialFileRCV.createNewFile();
                } else if (SerialRCVWrittenForFirst) {
                    serialFileRCV.delete();
                    serialFileRCV.createNewFile();
                    SerialRCVWrittenForFirst = false;
                }

                FileWriter fw = new FileWriter(serialFileRCV.getAbsoluteFile(), true);

                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter pn = new PrintWriter(fw);
                pn.println(content);
                pn.close();

                logger.info("Done");
            } catch (Exception e) {//Catch exception if any
                logger.info("Error in print dacFile");
            }
        }
        //End of writing


    }

    byte[] serialRequestMsgCreator(int simulationTime, int motePinId) {
        int uValue = 0;
        byte[] emptySerialData = new byte[16];
        for (byte b : emptySerialData) {
            b = 0;
        }
        logger.info("#simulationTime" + simulationTime);
        logger.info("#motePinId" + motePinId);

        byte[] simulationTimeInByte = int2Bytes(simulationTime);
        byte[] motePinIdInByte = int2Bytes(motePinId);
        byte[] uValueInByte = int2Bytes(uValue);

        byte[] message = combine(reverseArray(simulationTimeInByte), reverseArray(motePinIdInByte), reverseArray(uValueInByte), emptySerialData);

        for (byte b : message) {
            logger.info("#b" + b);
        }

        return (message);
    }

    byte[] serialMessageCreator(int simulationTime, int motePinId, byte[] serialMessage) {

        int uValue = 0;

        byte[] simulationTimeInByte = int2Bytes(simulationTime);
        byte[] motePinIdInByte = int2Bytes(motePinId);
        byte[] uValueInByte = int2Bytes(uValue);

        byte[] message = combine(reverseArray(simulationTimeInByte), reverseArray(motePinIdInByte), reverseArray(uValueInByte), serialMessage);

        return (message);
    }

    int serialMsgSender(byte[] message, DatagramSocket dgSocket) {

        try {
            InetAddress IPAddress = InetAddress.getByName("localhost");
            DatagramPacket dgPacket = new DatagramPacket(message, message.length, IPAddress, 55555);
            dgSocket.send(dgPacket);
        } catch (IOException ex) {
            System.out.println("Error in sending dgPacket in adcRequestSender!!");
        }
        byte[] receivedValue = new byte[4];
        DatagramPacket receivedPacket = new DatagramPacket(receivedValue, receivedValue.length);
        try {
            dgSocket.receive(receivedPacket);
        } catch (IOException ex) {
            System.out.println("Error in receive UDP data adcRequestSender!!");
            System.out.println(ex.getMessage());
        }
     //   byte[] data = reverseArray(receivedPacket.getData());
        byte[] data = receivedPacket.getData();
        return (bytes2Int(data));
    }

    void serialRequestSender(byte[] requestMessage, DatagramSocket dgSocket) {




        try {
            logger.info("*1");
            InetAddress IPAddress = InetAddress.getByName("localhost");
            logger.info("*2");
            DatagramPacket dgPacket = new DatagramPacket(requestMessage, requestMessage.length, IPAddress, 55555);
            dgSocket.send(dgPacket);
        } catch (IOException ex) {
            System.out.println("Error in sending dgPacket in adcRequestSender!!");
        }
        logger.info("*2.5");
        byte[] receivedSerialData = new byte[30];
        DatagramPacket receivedPacket = new DatagramPacket(receivedSerialData, receivedSerialData.length);
        try {
            logger.info("*3");
            dgSocket.receive(receivedPacket);
        } catch (IOException ex) {
            System.out.println("Error in receive UDP data adcRequestSender!!");
            System.out.println(ex.getMessage());
        }
        logger.info("*4");
        byte[] data = reverseArray(receivedPacket.getData());
        logger.info("*5");
        for (int i = 0; i < data.length; i++) {
            serialPort.writeByte(data[i]);
            logger.info("Data written in serial port: " + data[i]);
            //logger.info("*6");
        }
        logger.info("*7");


//        
//        
//        
//
//        try {
//            InetAddress IPAddress = InetAddress.getByName("localhost");
//            DatagramPacket dgPacket = new DatagramPacket(requestMessage, requestMessage.length, IPAddress, 55555);
//            reqSenderDSocket.send(dgPacket);
//        } catch (IOException ex) {
//            System.out.println("Error in sending dgPacket in serialDataRequestSender!!");
//        }
//        int numRead = 0;
//        byte[] data = new byte[1024];
//        numRead = -1;
//        try {
//            logger.info("##in serialrequest sender befor read");
//            numRead = inStrmToReceiveReply.read(data);
//        } catch (IOException e) {
//            logger.info("#in serialrequest sender catch");
//            numRead = -1;
//        }
//        logger.info("##in serialrequest sender after read");
//        if (numRead >= 0) {
//            for (int i = 0; i < numRead; i++) {
//                serialPort.writeByte(data[i]);
//                logger.info("Data written in serial port: " + data[i]);
//            }
//        } else {
//            cleanupClient();
//        }
    }

    byte[] combine(byte[] one, byte[] two) {
        byte[] combined = new byte[one.length + two.length];

        System.arraycopy(one, 0, combined, 0, one.length);
        System.arraycopy(two, 0, combined, one.length, two.length);
        return combined;
    }

    byte[] combine(byte[] one, byte[] two, byte[] three) {
        byte[] combined = new byte[one.length + two.length + three.length];

        System.arraycopy(one, 0, combined, 0, one.length);
        System.arraycopy(two, 0, combined, one.length, two.length);
        System.arraycopy(three, 0, combined, one.length + two.length, three.length);
        return combined;
    }

    byte[] combine(byte[] one, byte[] two, byte[] three, byte[] four) {
        byte[] combined = new byte[one.length + two.length + three.length + four.length];

        System.arraycopy(one, 0, combined, 0, one.length);
        System.arraycopy(two, 0, combined, one.length, two.length);
        System.arraycopy(three, 0, combined, one.length + two.length, three.length);
        System.arraycopy(four, 0, combined, one.length + two.length + three.length, four.length);
        return combined;
    }

    byte[] reverseArray(byte[] inputArray) {
        byte[] reverseArray = new byte[inputArray.length];
        for (int i = 0; i < inputArray.length; i++) {
            reverseArray[i] = inputArray[(inputArray.length - 1) - i];
        }
        return reverseArray;

    }

    byte[] int2Bytes(int inputInt) {

        byte[] resultByts = new byte[]{
            (byte) ((inputInt >> 24) & 0xff),
            (byte) ((inputInt >> 16) & 0xff),
            (byte) ((inputInt >> 8) & 0xff),
            (byte) ((inputInt >> 0) & 0xff),};
        return resultByts;
    }

    int bytes2Int(byte[] bytes) {
        return ((int) (0xff & bytes[0]) << 24
                | (int) (0xff & bytes[1]) << 16
                | (int) (0xff & bytes[2]) << 8
                | (int) (0xff & bytes[3]) << 0);
    }

    private void cleanupClient() {
        try {
            if (client != null) {
                client.close();
                client = null;
            }
        } catch (IOException e1) {
        }
        try {
            if (in != null) {
                in.close();
                in = null;
            }
        } catch (IOException e) {
        }


        if (GUI.isVisualized()) {
            SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    statusLabel.setText("Listening on port: " + LISTEN_PORT);
                }
            });
        }
    }

    public JPanel getInterfaceVisualizer() {
        JPanel panel = new JPanel(new GridLayout(0, 2));
        panel.add(new JLabel("Light1"));
        panel.add(new JLabel("Light2"));


        return panel;
    }

    public void releaseInterfaceVisualizer(JPanel panel) {
    }

    public Collection<Element> getConfigXML() {
        return null;
    }

    private JLabel configureLabel(JComponent pane, String desc, String value) {
        JPanel smallPane = new JPanel(new BorderLayout());
        JLabel label = new JLabel(desc);
        label.setPreferredSize(new Dimension(LABEL_WIDTH, LABEL_HEIGHT));

        label = new JLabel(value);
        label.setPreferredSize(new Dimension(LABEL_WIDTH, LABEL_HEIGHT));
        smallPane.add(BorderLayout.WEST, label);
        pane.add(smallPane);
        return label;
    }

    public boolean setConfigXML(Collection<Element> configXML, boolean visAvailable) {
        return true;
    }

    public void closePlugin() {
        dSocket.close();
    }

    public Mote getMote() {
        return mote;
    }
    /**
     *
     */
//    boolean a=true;
//    protected class checkBoxChengeListener implements ChangeListener{
//
//        @Override
//        public void stateChanged(ChangeEvent e) {
//           if (e.getSource()==serialDataShouldRCV){
//               if(serialDataShouldRCV.isSelected()){
//                   try {
//                       if (a){
//                       client = server.accept();
//                       in = new DataInputStream(client.getInputStream());
//                       a=false;
//                       logger.info("in has been created!!!!");
//                       }
//                   } catch (IOException ex) {
//                       logger.info("Error in the create client and in 404");
//                       
//                       java.util.logging.Logger.getLogger(SimulinkConnector.class.getName()).log(Level.SEVERE, null, ex);
//                   }
//                }
//           }
//            
//            
//            // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//        }
//    
//    }
}
