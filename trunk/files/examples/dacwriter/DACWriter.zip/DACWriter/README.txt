$Id: README.txt, v 1.4 2013/11/19 11:22:29  $

README for DACWriter


Author/Contact:

  behdad@kth.se

Description:

DACWriter

The DACWriter application is a sample application to show how to write new DAC data on the sky mote. This application will write a counter value on DAC0. Whenever a DAC data is written, the led0 will toggle. 
