/**
 * Copyright (c) 2007, Swedish Institute of Computer Science.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the Institute nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * This file is part of MSPSim.
 *
 * $Id: ADC12.java 479 2009-03-11 22:28:15Z joxe $
 *
 * -----------------------------------------------------------------
 *
 * ADC12
 *
 * Each time a sample is converted the ADC12 system will check for EOS flag
 * and if not set it just continues with the next conversion (x + 1). 
 * If EOS next conv is startMem.
 * Interrupt is triggered when the IE flag are set! 
 *
 *
 * Author  : Joakim Eriksson
 * Created : Sun Oct 21 22:00:00 2007
 * Updated : $Date: 2009-03-11 23:28:15 +0100 (Wed, 11 Mar 2009) $
 *           $Revision: 479 $
 */
package se.sics.mspsim.core;

public class DAC12 extends IOUnit {

    private static final boolean DEBUG = false;
    public static final int DAC12_0CTL = 0x01C0;// Reset with POR
    public static final int DAC12_1CTL = 0x01C2;// Reset with POR
    public static final int DAC12_0DAT = 0x01C8; //Reset with POR
    public static final int DAC12_1DAT = 0x01CA; //Reset with POR
    public static final int DAC12GRP = 0x0001; //Reset with POR
    public static final int DAC12ENC = 0x0002; //Unchanged
    public static final int DAC12IFG = 0x0004; //Unchanged
    public static final int DAC12IE = 0x0008; //Unchanged
    public static final int DAC12DF = 0x0010; //Unchanged
    public static final int DAC12AMP0 = 0x0020; //Unchanged
    public static final int DAC12AMP1 = 0x0040; //Unchanged
    public static final int DAC12AMP2 = 0x0080; //Unchanged
    public static final int DAC12IR = 0x0100; //Unchanged
    public static final int DAC12CALON = 0x0200; //Unchanged
    public static final int DAC12LSEL0 = 0x0400; //Unchanged
    public static final int DAC12LSEL1 = 0x0800; //Unchanged
    public static final int DAC12RES = 0x1000; //Unchanged
    public static final int DAC12SREF0 = 0x2000; //Unchanged
    public static final int DAC12SREF1 = 0x4000; //Unchanged
    public static final int DAC12OPS = 0x8000; //Unchanged
    public static final int DAC12AMP_0 = 0; //Unchanged
    public static final int DAC12AMP_1 = 1; //Reset with POR
    public static final int DAC12AMP_2 = 2; //Reset with POR
    public static final int DAC12AMP_3 = 3; //Reset with POR
    public static final int DAC12AMP_4 = 4; //Reset with POR
    public static final int DAC12AMP_5 = 5; //Reset with POR
    public static final int DAC12AMP_6 = 6; //Reset with POR
    public static final int DAC12AMP_7 = 7; //Reset with POR
    public static final int DAC12LSEL_0 = 0; //Reset with POR
    public static final int DAC12LSEL_1 = 1; //Reset with POR
    public static final int DAC12LSEL_2 = 2; //Reset with POR
    public static final int DAC12LSEL_3 = 3; //Reset with POR
    public static final int DAC12SREF_0 = 0; //Reset with POR
    public static final int DAC12SREF_1 = 1; //Reset with POR
    public static final int DAC12SREF_2 = 2; //Reset with POR
    public static final int DAC12SREF_3 = 3; //Reset with POR
    private int dac12ctl0 = 0;
    private int dac12ctl1 = 0;
    private int dac12dat1 = 10;
    private int dac12dat0 = 20;
    private int dac12amp0 = 0;
    private int dac12lsel0 = 0;
    private int dac12sRef0 = 0;
    private boolean dac12grp0;
    private boolean dac12enc0;
    private boolean dac12ifg0;
    private boolean dac12ie0;
    private boolean dac12df0;
    private boolean dac12ir0;
    private boolean dac12CalOn0;
    private boolean dac12Res0;
    private int dac12amp1 = 0;
    private int dac12lsel1 = 0;
    private int dac12sRef1 = 0;
    private boolean dac12grp1;
    private boolean dac12enc1;
    private boolean dac12ifg1;
    private boolean dac12ie1;
    private boolean dac12df1;
    private boolean dac12ir1;
    private boolean dac12CalOn1;
    private boolean dac12Res1;
    private DACOutput dacOutput[] = new DACOutput[2];
    private MSP430Core core;
    private boolean dat0IsWritten = false;
    
    
    private TimeEvent dacTrigger = new TimeEvent(0) {        

        public void execute(long t) {
//      System.out.println(getName() + " **** executing update timers at " + t + " cycles=" + core.cycles);
            convert();
        }
    };

    public DAC12(MSP430Core cpu) {

        super("DAC12", cpu, cpu.memory, 0);
    }

    public void setDACOutput(int index, DACOutput outputObj) {
        dacOutput[index] = outputObj;
    }

    // write a value to the IO unit
    public void write(int address, int value, boolean word,
            long cycles) {
        switch (address) {
            case DAC12_0CTL:
                dac12ctl0 = value;
                dac12grp0 = (value & 0x01) > 0;
                dac12enc0 = (value & 0x02) > 0;
                dac12ifg0 = (value & 0x04) > 0;
                dac12ie0 = (value & 0x08) > 0;
                dac12df0 = (value & 0x10) > 0;
                dac12amp0 = (value >> 5) & 0x07;
                dac12ir0 = ((value >> 8) & 0x01) > 0;
                dac12CalOn0 = ((value >> 8) & 0x02) > 0;
                dac12lsel0 = (value >> 10) & 0x03;
                dac12Res0 = ((value >> 12) & 0x01) > 0;
                dac12sRef0 = (value >> 12) & 0x06;
                System.out.println("Writing on DAC12_0CTL  value: " + value);

                /*  
                if (DEBUG) System.out.println(getName() + ": Set SHTime0: " + shTime0 + " SHTime1: " + shTime1 + " ENC:" +
                enableConversion + " Start: " + startConversion + " ADC12ON: " + adc12On);
                
                if (dac12enc) {
                // Set the start time to be now!
                //   dacTrigger.time = core.getTime();
                convert();
                }*/
                break;
            case DAC12_1CTL:
                dac12ctl1 = value;
                dac12grp1 = (value & 0x01) > 0;
                dac12enc1 = (value & 0x02) > 0;
                dac12ifg1 = (value & 0x04) > 0;
                dac12ie1 = (value & 0x08) > 0;
                dac12df1 = (value & 0x10) > 0;
                dac12amp1 = (value >> 5) & 0x07;
                dac12ir1 = ((value >> 8) & 0x01) > 0;
                dac12CalOn1 = ((value >> 8) & 0x02) > 0;
                dac12lsel1 = (value >> 10) & 0x03;
                dac12Res1 = ((value >> 12) & 0x01) > 0;
                dac12sRef1 = (value >> 12) & 0x06;
                System.out.println("Writing on DAC12_1CTL  value: " + value);

                break;
            case DAC12_0DAT:
                dac12dat0 = value;
                dat0IsWritten = true;
//		System.out.println("Writing on DAC12_0DAT  value: "+value);                
                if (dac12lsel0 == 0) {
                    convert();
                } else if (dac12lsel0 == 1) {
                    if (dac12grp0) {
                        convert();
                    } else {
                        convert();  // group writing opertaion has to be implemented here: wait untill the other data register (DAC12_1DAT) get new value

                    }
                } else if (dac12lsel0 == 2) {
                    convert();		//clock based operation shouold be implemented here
                } else if (dac12lsel0 == 3) {
                    convert();		//clock based operation shouold be implemented here  		
                }



                break;
            case DAC12_1DAT:
                dac12dat1 = value;
                dat0IsWritten = false;
                //System.out.println("Writing on DAC12_1DAT  value: "+value);
                if (dac12lsel1 == 0) {
                    convert();
                } else if (dac12lsel1 == 1) {
                    if (dac12grp1) {
                        convert();
                    } else {
                        convert();  // group writing opertaion has to be implemented here: wait untill the other data register (DAC12_1DAT) get new value

                    }
                } else if (dac12lsel1 == 2) {
                    convert();		//clock based operation shouold be implemented here
                } else if (dac12lsel1 == 3) {
                    convert();		//clock based operation shouold be implemented here  		
                }

                break;

        }
    }

// read a value from the IO unit
    public int read(int address, boolean word, long cycles) {
        switch (address) {
            case DAC12_0CTL:
                return dac12ctl0;
            case DAC12_1CTL:
                return dac12ctl1;
            case DAC12_0DAT:
                return dac12dat0;
            case DAC12_1DAT:
                return dac12dat1;


        }
        return 0;
    }

    public String getName() {
        return "DAC12";
    }
    int smp = 0;

    private void convert() {
        // If either off or not enable conversion then just return...

        int toBeSent = 0;
        
        // Some noice...
        if (dat0IsWritten) {
        if (!dac12enc0) {
            return;
        }
            if (dac12Res0) {
                toBeSent = (dac12dat0 & 0x00ff);
            } else {
                toBeSent = (dac12dat0 & 0x0fff);
            }
            (dacOutput[0]).setDACPin0(toBeSent);
        } else {
        if (!dac12enc1) {
            return;
        }
            if (dac12Res1) {
                toBeSent = (dac12dat1 & 0x00ff);
            } else {
                toBeSent = (dac12dat1 & 0x0fff);
            }
            (dacOutput[1]).setDACPin1(toBeSent);
        }
        /*
        System.out.println("PIN 0: "+ dacOutput[0]);
        System.out.println("PIN 1: "+ dacOutput[1]);
        
        (dacOutput[1]).setDACPin1(dac12dat1);
        
        System.out.println(dac12dat0+dac12dat1);
         */
    }

    public void interruptServiced(int vector) {
    }
}
