package se.sics.mspsim.core;

public interface DACOutput {
   public void setDACPin0(int value);
   public void setDACPin1(int value);
}
